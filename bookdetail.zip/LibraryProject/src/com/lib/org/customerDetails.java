package com.lib.org;

public class customerDetails {

	String name;
	int quantity[];
	double price[];
	String location;
	int bookId[];
	
	public customerDetails(String name, int[] quantity, double[] price, String location, int[] bookId) {
		super();
		this.name = name;
		this.quantity = quantity;
		this.price = price;
		this.location = location;
		this.bookId = bookId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int[] getQuantity() {
		return quantity;
	}

	public void setQuantity(int[] quantity) {
		this.quantity = quantity;
	}

	public double[] getPrice() {
		return price;
	}

	public void setPrice(double[] price) {
		this.price = price;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int[] getBookId() {
		return bookId;
	}

	public void setBookId(int[] bookId) {
		this.bookId = bookId;
	}
	
	
	
}
