package com.lib.org;

import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;

public class LibMethod 
{
	Scanner scan=new Scanner(System.in);
	Scanner sc=new Scanner(System.in);
	String name;
	int qty = 0;
	int book_quantity;
	int	temp_bookquantity;
	String cont;
	double total = 0;
	static HashMap<String,BookDetails> map = new HashMap<String,BookDetails>(10);
	static HashMap<String,BookDetails> customer = new HashMap<String,BookDetails>(10);
	public static HashMap<String, BookDetails> 
	init() 
	{
		// initialize our Book Details objects
		BookDetails bookMap = new BookDetails("JAVA",  100.00,0);
		BookDetails bookMap1 = new BookDetails("WEB",  200.00,0);
		BookDetails bookMap2= new BookDetails(".NET",  300.00,0);
		BookDetails bookMap3= new BookDetails("ORACLE", 400.00,0);


		map.put(bookMap.getBookName(), bookMap);
		map.put(bookMap1.getBookName(), bookMap1);
		map.put(bookMap2.getBookName(),bookMap2);
		map.put(bookMap3.getBookName(),bookMap3);

		return map;

	}
	
	
	void display()
	{
		System.err.println("Available Books to Buy");
		if(!map.isEmpty())
		{
			System.out.println("Books \t Price");
			for (String s : map.keySet()) 
			{
				System.out.println(map.get(s).getBookName()+"\t"+map.get(s).getPrice() );

			}
			
		}
	}


	public void addToCart() {
		do{	
			System.out.println("Enter the Book to Add Cart");
			name=sc.next();
			name=name.toUpperCase();
			System.out.println("Enter the Quantity");
			qty=sc.nextInt();
			
			BookDetails b5=map.get(name);
	
			if(map.containsKey(name));
			{
				for(int i=1;i<=qty;i++)
				{
					if(b5.quantity>9)
					{
						b5.quantity=10;
						System.out.println("Same book exceeded more than 10times\nMax quantity 10 Books are in your cart\n");
						break;
					}
					else if(qty<11)
					{	
						b5.quantity++;
						customer.put(name, b5);
						
					}
					else
					{
						b5.quantity=10;
						customer.put(name, b5);
					}
				}
			}
			System.out.println("Add another item? (y/n) ");
			cont = scan.nextLine();
			cont = cont.toLowerCase();
			
			
		} while (cont.startsWith("y"));
			
			
			display_cart();
	
		
	}
	

	static void display_cart()
	{
		 System.out.println("\n Shopping List Items\n");
		 for (String name : customer.keySet()) 
		 {
			 String value = customer.get(name).toString();
			 System.out.println(value);
		 }
		 checkOut();
		
	}


	public static void checkOut() {
		double price=0.0;
		
		Collection<BookDetails> collectionValues = customer.values();
		for(BookDetails s: collectionValues)
		{
			price+=s.getPrice()*s.quantity;
			
		}
		
	
    System.out.println("The Totoal Amount to be paid : "+price);

		// TODO Auto-generated method stub
		
	}
}
