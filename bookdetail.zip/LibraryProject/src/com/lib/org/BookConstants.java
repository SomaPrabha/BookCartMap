package com.lib.org;

import java.util.HashMap;

public class BookConstants {
	
	
	
	static HashMap<String,BookDetails> map = new HashMap<String,BookDetails>();
	HashMap<String,BookDetails> customer = new HashMap<String,BookDetails>();
	String name;
	int count;
	int quantity;
	
}
