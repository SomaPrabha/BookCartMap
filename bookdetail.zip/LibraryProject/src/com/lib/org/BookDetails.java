package com.lib.org;

public class BookDetails {
	

	@Override
	public String toString() {
		return "BookDetails [bookName=" + bookName + ", price=" + price + ", quantity=" + quantity
				+ "]";
	}



	private String bookName;
	private double price;
	private int count;
	int quantity;
	 
	 public BookDetails(String name, double price, int quantity)
		{
		
			this.bookName=name;
			this.price=price;
			this.quantity=quantity;
			
		}

	public String getBookName() {
		return bookName;
	}



	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	  
	public void increment(int increment) {
	        setCount(getCount() + 1);
	    }



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	public int getCount() {
		return count;
	}



	public void setCount(int count) {
		this.count = count;
	}







	
	
	





}
