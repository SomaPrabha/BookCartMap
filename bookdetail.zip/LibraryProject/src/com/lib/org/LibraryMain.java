package com.lib.org;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;



public class LibraryMain extends LibMethod {




	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		
	
		LibMethod lm=new LibMethod();
		map=init();
		for(;;)
		{
			System.out.println("Press 1 to Check Book Details");
			System.out.println("Press 2 to Add Card");
			System.out.println("Press 3 to Exit");
			int n=sc.nextInt();
			
			switch(n)
			{
			case 1 :
				lm.display();
			
				break;

			case 2 : 
				lm.addToCart();
				
				break;
	
			case 3 : System.exit(0);
			default : System.out.println("Invalid Option"); break;
			}
		}
	}

}
